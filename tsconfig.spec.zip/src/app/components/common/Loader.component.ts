import { Component } from '@angular/core';

@Component({
    selector: 'app-fileLoader',
    template: `<div  class="loader-wrapper">
    <div class="loader"></div>
</div>`
})

export class FileLoader {

}