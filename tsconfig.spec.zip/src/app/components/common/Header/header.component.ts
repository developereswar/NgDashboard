import { Component } from '@angular/core';
@Component({
    selector:'app-Header',
    templateUrl:'./header.component.html'
})
export class Header{

}