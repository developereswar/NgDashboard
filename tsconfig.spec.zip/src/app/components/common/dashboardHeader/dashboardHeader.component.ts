import { Component } from '@angular/core';

@Component({
    selector:'app-dashboardHeader',
    templateUrl:'./dashboardHeader.component.html'
})

export class DashboardHeader{

}