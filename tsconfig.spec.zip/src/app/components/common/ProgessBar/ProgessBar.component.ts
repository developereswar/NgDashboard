import { Component } from '@angular/core';

@Component({
    selector:'app-ProgessBar',
    templateUrl:'./ProgessBar.component.html',
    styleUrls:['ProgressBar.component.css']
})

export class ProgessBar{
    constructor(){

    }

    
}