import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
    templateUrl:'./inbox.component.html',
    selector:'app-inbox'
})
export class InboxComponent{
    constructor( private router: Router){

    }

    

}